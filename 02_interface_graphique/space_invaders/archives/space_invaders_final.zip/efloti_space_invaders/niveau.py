class Niveau:
    
    def __init__(self):
        self.dts = [1000, 500, 400, 300, 200, 100]
        self._idx = -1
        self._i = 0
        self._imax = 3 #3
        self.tps_changement = 120 * 1000 # 2 minutes

    def dt_suivant(self):
        if self._idx < len(self.dts) - 1:
            self._idx += 1
        return self.dts[self._idx]
    
    def suivant(self):
        self._idx = -1
        if not self._i < self._imax: return
        self._i += 1
        self.tps_changement -= 30 * 1000 # moins 30 secondes
    
    def est_dernier(self):
        if self._i == self._imax :
            return True
        return False
