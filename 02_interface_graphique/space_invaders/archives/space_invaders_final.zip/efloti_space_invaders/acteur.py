# module space_invaders/acteur.py     

class Acteur:
    
    def __init__(self, scene, images, marque, taille_pixel):
        self.fen = scene.fen
        self.scene = scene
        
        self.taille_pixel = taille_pixel
        self.image_courante = images[0] 
        self.imgcn = 0
        self.images = images
        
        self.position = (0, 0)
        self.dimension = self.images[0].largeur * taille_pixel, self.images[0].hauteur * taille_pixel
        self.vitesse = (0, 0) # pixel par seconde
        
        self.marque = marque
        
        self.vivant = True
        self.en_pause = scene.en_pause
        self.invincible = False
        
    def deplacer(self, duree):
        if not self.vivant or self.en_pause: return
        x, y = self.position
        dx, dy = self.dxy(duree)
        self.position = x + dx, y + dy
        self.scene.move(self.marque, dx, dy)
    
    def dxy(self, duree):
        vx, vy = self.vitesse
        return vx * duree, vy * duree
    
    def est_dans_scene(self, position=None):
        x, y = position if position else self.position
        l, h = self.dimension
        L, H = self.scene.dimension
        if x < 0 or x + l > L or y < 0 or y + h > H:
            return False
        return True
    
    def est_hors_scene(self):
        x, y = self.position
        l, h = self.dimension
        L, H = self.scene.dimension
        if x + l < 0 or x > L or y + h < 0 or y > H:
            return True
        return False

    def afficher(self):
        self.scene.dessiner_acteur(self)
    
    def effacer(self):
        self.scene.effacer_acteur(self)
    
    def supprimer(self):
        if not self.vivant: return
        self.vivant = False
        self.scene.supprimer_acteur(self)
    
    def pause(self):
        self.en_pause = not self.en_pause
    
    def image_suivante(self):
        nb_images = len(self.images)
        if nb_images == 1: return
        if self.imgcn + 1 == nb_images:
            self.imgcn = 0
        else:
            self.imgcn += 1
        self.image_courante = self.images[self.imgcn]
        self.effacer()
        self.afficher()

    def toucher(self, acteur):
        return NotImplemented()
    
    def get_pixel(self, x, y):
        x0, y0 = self.position
        l, h = self.dimension
        if not (x0 <= x < x0 + l and  y0 <= y < y0 + h):
            return
        else:
            i = (y - y0) // self.taille_pixel
            j = (x - x0) // self.taille_pixel
        if self.image_courante.bitmap[i][j] == '1':
            return (i, j)

    def get_bbox(self):
        x, y = self.position
        l, h = self.dimension
        return (x, y, x+l, y+h)
    
    def recharger(self):
        pass
    
    def bascule_invincible(self):
        self.invincible = not self.invincible
    
    def __del__(self):
        pass
        # ~ print(f"del {self}")

if __name__ == "__main__":
    from tkinter import Tk
    from scene import Scene
    from image import Image
    from bitmaps import vaisseau

    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    a = Acteur(scene, [Image(vaisseau)], "test", 4)
    a.position = 1000//2, 800-100
    a.afficher()
    fen.mainloop()
