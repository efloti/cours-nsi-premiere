import tkinter as tk

class SpaceInvaders:
    
    def __init__(self):
        self.fen = tk.Tk()
        self.scenes = []
        self.hero = None
        self.envahisseurs = []
        self.decors = []
        self.missiles = []
        self.infos = []
        self.etat = None
    
    def transition(self, action):
        pass
    
    
