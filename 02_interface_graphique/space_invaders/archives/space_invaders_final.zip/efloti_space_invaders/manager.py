# module space_invaders/manager.py

from hero import Hero
from bouclier import Bouclier
from meute import Meute
from envahisseurs import EnvahisseurMere, EnvahisseurFils1, EnvahisseurFils2, EnvahisseurFils3
from missile import Missile

class Manager():
    
    NB_BOUCLIERS = 6
    
    def __init__(self, scene):
        self.scene
        self.acteurs = {
            Missile: [],
            Bouclier: [],
            Hero: None,
            Meute: None,
            EnvahisseurMere: None,
        }
        self.nb_vies = 0
        self.score = 0
        
    def mort_hero(self):
        if self.nb_vies == 0:
            self.fin_jeu()
        else:
            self.nb_vies -= 1
            self.nouvel_hero()
            
    def mort_envahisseur(self, env):
        pass
    
    def lancer_jeu(self):
        pass
    
    def parcourir_acteurs(self):
        pass
        
    def fin_jeu(self):
        pass
    
    def nouvel_hero(self):
        pass
    
    def activer_collision(self):
        pass
