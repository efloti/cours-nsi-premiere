# module space_invaders/main.py
from tkinter import Tk

from scene import Scene
from affichage import AffichageIntro, AffichageInfos

from hero import Hero
from meute import Meute
from envahisseurs import EnvahisseurMere

from niveau import Niveau

from random import randint
from time import sleep

class Jeu:
    
    NB_VIES = 3
    
    def __init__(self, fen):
        self.fen = fen
        self.en_marche = False
        
        self.affichage_intro = AffichageIntro(fen)
        self.affichage_infos = AffichageInfos(fen, self.NB_VIES)
        self.scene = Scene(fen)
        self.scene.jeu = self
        
        self.score = 0
        self.vies = self.NB_VIES
        self.meute = None
        
        self.niveau = None

        self._annul_creer_nouvel_hero = 0
        self._annul_vaisseau_mere = 0
        self._annul_gestion_meute = 0
        
        self._initialiser()
    
    def _initialiser(self):

        self.en_marche = False
        self.score = 0
        self.vies = self.NB_VIES
        self.meute = None
        self._annul_gestion_meute = 0
        self.niveau = Niveau()
        
        self.affichage_intro.pack()
        self.fen.after(2000, self._ecouter)
    
    def reinitialiser(self):
        self.scene.pack_forget()
        self.scene.reinitialiser(self)
        self.affichage_infos.pack_forget()
        self.affichage_infos.reinitialiser(self.NB_VIES)
        
        self._initialiser()

    def _ecouter(self):
        self.fen.bind('<Key>', self.demarrer_jeu)

    def demarrer_jeu(self, evt):
        self._en_marche = True
        self.fen.unbind('<Key>')
        self.affichage_intro.pack_forget()
        
        self.creer_hero()

        self.meute = self.creer_meute()
        self.gerer_meute()
        self._annul_vaisseau_mere = self.fen.after(randint(10, 50) * 1000, self.creer_vaisseau_mere)
        
        self.affichage_infos.pack()
        self.scene.pack()

    def mise_a_jour_score(self, points):
        if not self._en_marche: return
        if points > 0:
            self.score += points
            self.affichage_infos.mise_a_jour_score(self.score)

    def mise_a_jour_vies(self):
        if not self._en_marche: return
        if self.vies == 0:
            self.scene.afficher_game_over()
            self.fen.after(5000, self.terminer_jeu)
        else:
            self.vies -= 1
            self.affichage_infos.mise_a_jour_vies(self.vies)
            self.annul_creer_nouvel_hero = self.fen.after(1000, self.creer_nouvel_hero)

    def niveau_suivant(self):
        self._annul_after()
        
        if self.niveau.est_dernier():
            self.victoire()
            return
        
        self.niveau.suivant()
        self.creer_meute()
        self.gerer_meute()
        self._annul_vaisseau_mere = self.fen.after(randint(10, 50) * 1000, self.creer_vaisseau_mere)

    def terminer_jeu(self):
        self._annul_after()
        self.reinitialiser()

    def victoire(self):
        self.scene.afficher_bravo()
        self.fen.after(10000, self.reinitialiser)

    def _annul_after(self):
        if self._annul_creer_nouvel_hero != 0: 
            self.fen.after_cancel(self._annul_creer_nouvel_hero)
        if self._annul_vaisseau_mere != 0:
            self.fen.after_cancel(self._annul_vaisseau_mere)
        if self._annul_gestion_meute != 0:
            self.fen.after_cancel(self._annul_gestion_meute)

    def creer_vaisseau_mere(self):
        if not self._en_marche: return
        dt = randint(10, 50) * 1000
        
        self._annul_vaisseau_mere = self.fen.after(dt, self.creer_vaisseau_mere)
        
        if not self.scene.en_pause:
            EnvahisseurMere(self.scene)

    def creer_nouvel_hero(self):
        hero = self.creer_hero()
        hero.bascule_invincible()
        self._annul_creer_nouvel_hero = self.fen.after(3000, hero.bascule_invincible)
    
    def creer_hero(self):
        hero = Hero(self.scene)
        l, h = self.scene.dimension
        hero.position = l // 2, h - 50
        hero.vitesse = 500, 0
        hero.afficher()
        return hero
    
    def creer_meute(self):
        meute = Meute(self.scene)
        self.meute = meute
        meute.afficher()
        meute.lancer()
        meute.tirer()
        return meute

    def gerer_meute(self):
        if not self.meute: return
        self.meute.set_dt(self.niveau.dt_suivant())
        self._annul_gestion_meute = fen.after(self.niveau.tps_changement, self.gerer_meute)
    
    def nettoyer(self):
        self._annul_after()
        self.scene.nettoyer()
        self.fen.quit()

if __name__ == "__main__":
    from tkinter import Tk
    fen = Tk()
    fen.title("space invaders")
    jeu = Jeu(fen)
    # cf https://stackoverflow.com/questions/111155/how-do-i-handle-the-window-close-event-in-tkinter
    fen.protocol("WM_DELETE_WINDOW", jeu.nettoyer)
    fen.mainloop()
    


