TOUCHES = ['Left', 'Right', 'space']

class Touche:
    
    def __init__(self, fen, touche_descr):
        self.touche = touche_descr
        self.enfonce = False
        self.t1 = 0
        self.t2 = 0
        self.fen = fen
        fen.bind(
            f"<Key-{self.touche}>",
            self.appuie
        )
        fen.bind(
            f"<KeyRelease-{self.touche}>",
            self.relachement
        )
        
    def appuie(self, e):
        self.t1 = e.time
        self.enfonce = True
    
    def relachement(self, e):
        # un faux relachement de la touche génère immédiatement un faux appui
        self.t2 = e.time
        self.fen.after(5, self._set_false)
    
    def _set_false(self):
        if self.t1 != self.t2:
            self.enfonce = False
    
    def est_enfonce(self):
        return self.enfonce
    
    def supprimer(self):
        self.fen.unbind(f"<Key-{self.touche}>")
        self.fen.unbind(f"<KeyRelease-{self.touche}")
        
    def __str__(self):
        return f"{self.touche} {self.est_enfonce()}"

class Clavier:
    
    def __init__(self, fen, code_touches=None):
        self.touches = { code_touche: Touche(fen, code_touche) for code_touche in code_touches }
    
    def ecouter(code_touche):
        self.touches[code_touche] = Touche(code_touche)
    
    def est_enfonce(self, code_touche):
        touche = self.touches[code_touche]
        return touche.est_enfonce()
    
    def supprimer(self):
        for touche in self.touches.values():
            touche.supprimer()


if __name__ == "__main__":
    from tkinter import Tk
    fen = Tk()

    clavier = Clavier(fen, TOUCHES)

    fen.mainloop()
