from tkinter import Canvas
from image import Image
from bitmaps import vaisseau, envahisseur_mere, envahisseur_fils_1a, envahisseur_fils_2a, envahisseur_fils_3a, lettres

vaisseau = Image(vaisseau)
lettres = { k: Image(v) for k, v in lettres.items() }

class Affichage(Canvas):
    
    def __init__(self, fen, height):
        super().__init__(fen, width=1000, height=height, bg="black")
        self.fen = fen
        self.dimension = int(self["width"]), int(self["height"])
    
    def dessiner_image(self, x, y, image, taille_pixel, marque):
        tp = taille_pixel
        for i, j in image:
            self.create_rectangle(x + j * tp, y + i * tp, x + (j+1) * tp, y + (i+1) * tp, width=0, fill=image.couleur, tags=(marque, f"{i},{j}"))
        return image.largeur*taille_pixel
    
    def dessiner_lettre(self, x, y, lettre, taille_pixel, marque):
        return self.dessiner_image(x, y, lettre, taille_pixel, marque)
        
    def dessiner_texte(self, x, y, texte, taille_pixel, marque, espacement=1):
        x_ = x
        for i in range(len(texte)):
            l = texte[i]
            if l == " ":
                x_ += 3 * espacement * taille_pixel
                continue
            assert l in lettres, f"Pas d'image pour {lettre.img_descr}"
            l_img = lettres[l]
            self.dessiner_lettre(x_ , y, l_img, taille_pixel, marque)
            x_ += (l_img.largeur + espacement) * taille_pixel
        return x_ - x
        
class AffichageScore(Affichage):

    def __init__(self, fen):
        super().__init__(fen, height=40)
        L, H = self.dimension
        tp = 3
        self.taille_pixel = tp
        self.vaisseau_tp = self.taille_pixel * 2 / 3
        self.espacement = 4 * tp
        self.marge = 20
        self.y = (H - 5 * tp) // 2
        
        l = self.dessiner_texte(self.marge, self.y, "score", tp, "score_label")
        self.x_score = self.marge + l + self.espacement
        
        l = self.dessiner_texte(0, 0, "vies", tp, "vies_label")
        x = L - self.marge - 3 * vaisseau.largeur * self.vaisseau_tp - 3 * self.espacement - l
        self.move("vies_label", x, self.y)
        self.x_vies = x + l + self.espacement
        
        self.mise_a_jour_score(1000)
        self.mise_a_jour_vies(3)
    
    def mise_a_jour_score(self, score):
        self.delete("score")
        self.dessiner_texte(self.x_score, self.y, str(score), self.taille_pixel, "score") 
    
    def mise_a_jour_vies(self, vies):
        self.delete("vies")
        x = self.x_vies
        for i in range(vies):
            lv = self.dessiner_image(x, self.y, vaisseau, self.vaisseau_tp, "vies")
            x += lv + self.espacement
        
class AffichageIntro(Affichage):
    
    def __init__(self, fen):
        super().__init__(fen, height=840)
        self.taille_pixel = 4
        L, H = self.dimension
        l1 = self.dessiner_texte(0, 0, "space invaders", 3 * self.taille_pixel, "titre")
        l2 = self.dessiner_texte(0, 0, "appuyer sur une touche pour continuer", self.taille_pixel, "sous_titre")
        l_env_m = self.dessiner_image(0, 0, Image(envahisseur_mere), self.taille_pixel, "env_m")
        l_env_f1 = self.dessiner_image(0, 0, Image(envahisseur_fils_1a), self.taille_pixel, "env_f1")
        l_env_f2 = self.dessiner_image(0, 0, Image(envahisseur_fils_2a), self.taille_pixel, "env_f2")
        l_env_f3 = self.dessiner_image(0, 0, Image(envahisseur_fils_3a), self.taille_pixel, "env_f3")
        l_pt1 = self.dessiner_texte(0, 0, " = 30 points", self.taille_pixel, "pt1")
        l_pt2 = self.dessiner_texte(0, 0, " = 20 points", self.taille_pixel, "pt2")
        l_pt3 = self.dessiner_texte(0, 0, " = 10 points", self.taille_pixel, "pt3")
        l_pt4 = self.dessiner_texte(0, 0, " = ??? points", self.taille_pixel, "pt4")
        y = 280
        self.move("titre", (L - l1) / 2, y)
        y += 100
        self.move("sous_titre", (L - l2) / 2, y)
        
        y += 50
        x = (L - (l_env_f3 + l_pt3)) / 2
        self.move("env_f3", x, y)
        self.move("pt1", x + l_env_f3, y)
        y += 50
        x = (L - (l_env_f2 + l_pt2)) / 2
        self.move("env_f2", x , y)
        self.move("pt2", x + l_env_f2, y)
        y += 50
        x = (L - (l_env_f1 + l_pt1)) / 2
        self.move("env_f1", x, y)
        self.move("pt3", x + l_env_f1, y)
        y += 50
        x = (L - (l_env_m + l_pt4)) / 2
        self.move("env_m", x, y)
        self.move("pt4", x + l_env_m, y)
        
        
if __name__ == "__main__":
    from tkinter import Tk
    from scene import Scene
    fen = Tk()
    af = AffichageIntro(fen)
    af.pack()
    fen.mainloop()
        
    
