# module space_invaders/image.py

def str_to_list(texte):
    l = texte[1:-1].split('\n')
    for i in range(len(l)):
        tmp = l[i]
        l[i] = list(tmp)
    return l

class Image:
    
    def __init__(self, img_descr):
        tmp = str_to_list(img_descr)
        self.img_descr = img_descr
        self.bitmap = tmp
        self.hauteur = len(tmp)
        self.largeur = len(tmp[0])
        self.couleur = "white"
        self.liste_bits = self.calculer_liste_bits()
    
    def __iter__(self):
        return iter(self.liste_bits)
    
    def suppr_pixel(self, i, j):
        self.bitmap[i][j] = '0'
        self.liste_bits = self.calculer_liste_bits()
    
    def suppr_pixel_avec_masque(self, masque, i0, j0):
        nb_suppr = 0
        for i in range(masque.hauteur):
            for j in range(masque.largeur):
                i_, j_ = i0 + i, j0 + j
                if 0 <= i_ < self.hauteur and 0 <= j_ < self.largeur:
                    b1 = self.bitmap[i_][j_]
                    b2 = masque.bitmap[i][j]
                    if b1 != '0' and b2 == '0':
                        self.bitmap[i_][j_] = '0'
                        nb_suppr += 1
        if nb_suppr > 0:
            self.liste_bits = self.calculer_liste_bits()
        return nb_suppr
        
    
    def get_colonne(self, j):
        col = []
        for i in range(self.hauteur):
            if self.bitmap[i][j] != '0':
                col.append(i)
        return col
    
    def get_dernier_bit_en_colonne(self, j):
        i_s = self.get_colonne(j)
        if i_s:
            return i_s[-1]

    def get_premier_bit_en_colonne(self, j):
        i_s = self.get_colonne(j)
        if i_s:
            return i_s[0]
    
    def calculer_liste_bits(self):
        return [ (i,j) for i in range(self.hauteur) for j in range(self.largeur) if self.bitmap[i][j] != '0']

if __name__ == "__main__":
    from bitmaps import vaisseau
    from random import randint
    v_img = Image(vaisseau)
    print(f"bitmap:\n {v_img.bitmap}")
    print(f"liste de bits:\n {v_img.liste_bits}")
    for _ in range(10):
        i = randint(0, v_img.hauteur-1)
        j = randint(0, v_img.largeur-1)
        v_img.suppr_pixel(i, j)
        print(f"liste de bits:\n {v_img.liste_bits}")
