# module space_invaders/scene.py
from affichage import Affichage
from explosion import Explosion
from bitmaps import bouclier
from envahisseurs import EnvahisseurMere, EnvahisseurFils
from hero import Hero
from image import Image

class Scene(Affichage):
    
    def __init__(self, fen):
        super().__init__(fen, height=800)
        self.jeu = None
        self.acteurs = {}
        self.en_pause = False
        self.vivant = True
        self._annul_bind = self.fen.bind('p', self.pause)
        self._annul_after = None
        
        self.dessiner_boucliers()
        self.surveiller_collision()
    
    def reinitialiser(self, jeu):
        self.nettoyer()
        self.jeu = jeu
        self.en_pause = False
        self.vivant = True
        self._annul_bind = self.fen.bind('p', self.pause)
        self._annul_after = None
        
        self.dessiner_boucliers()
        
        self.surveiller_collision()

    def toucher_acteur(self, acteur):
        for _id in self.find_overlapping(*acteur.get_bbox()):
            marques = self.gettags(_id)
            m, *_ = marques
            if m == acteur.marque: continue
            if m in self.acteurs:
                a = self.acteurs[m]
                return a

    def toucher_decor(self, acteur):
        ret = False
        for _id in self.find_overlapping(*acteur.get_bbox()):
            m, *_ = self.gettags(_id)
            if m == "bouclier":
                ret = True
                self.delete(_id)
        return ret

    def surveiller_collision(self):
        if not self.vivant: return
        self._annul_after = self.after(1000//25, self.surveiller_collision)
        if self.en_pause: return
        visites = {}
        copie = self.acteurs.copy()
        for acteur in copie.values():
            if acteur.marque not in visites:
                visites[acteur.marque] = acteur
                if self.toucher_decor(acteur):
                    acteur.toucher(acteur)
                    return
                autre = self.toucher_acteur(acteur)
                if autre and autre.marque not in visites:
                    acteur.toucher(autre)
                    autre.toucher(acteur)                
    
    def ajouter_acteur(self, acteur):
        if isinstance(acteur, Explosion) or not self.vivant: return
        if acteur.marque not in self.acteurs:
            self.acteurs[acteur.marque] = acteur
    
    def dessiner_acteur(self, acteur):
        x, y = acteur.position
        dpx = acteur.taille_pixel
        self.dessiner_image(x, y, acteur.image_courante, acteur.taille_pixel, acteur.marque)
        self.ajouter_acteur(acteur)
    
    def effacer_acteur(self, acteur):
        self.delete(acteur.marque)
    
    def supprimer_acteur(self, acteur):
        self.effacer_acteur(acteur)
        if acteur.marque not in self.acteurs or not self.vivant: return
        
        del self.acteurs[acteur.marque]
        if isinstance(acteur, EnvahisseurMere) or isinstance(acteur, EnvahisseurFils):
            self.jeu.mise_a_jour_score(acteur.points)
        if isinstance(acteur, Hero):
            self.jeu.mise_a_jour_vies()
    
    def fin_meute(self):
        self.jeu.niveau_suivant()
    
    def dessiner_boucliers(self):
        NB_BOUCLIER = 6
        b_img = Image(bouclier)
        taille_bit = 4
        lb = b_img.largeur * taille_bit 
        ls, hs = self.dimension
        espacement = (ls - NB_BOUCLIER * lb)//(NB_BOUCLIER + 1)
        y = hs - 200
        for n in range(NB_BOUCLIER):
            x = espacement + n * (lb + espacement)
            for i, j in b_img:
                _id = self.create_rectangle(x + j * taille_bit, y + i * taille_bit, x + (j+1) * taille_bit, y + (i+1) * taille_bit, width=0, fill="white", tags=("bouclier", f"{i},{j}"))
        
    def pause(self, evt):
        self.en_pause = not self.en_pause
        for acteur in self.acteurs.values():
            acteur.pause()
    
    def nettoyer(self):
        if not self.vivant: return
        self.vivant = False
        
        self.fen.after_cancel(self._annul_after)
        self.fen.unbind('p', self._annul_bind)
        
        self.delete("bouclier")
        
        for acteur in self.acteurs.copy().values():
            acteur.supprimer()
        self.acteurs = {}
    
    def afficher_game_over(self):
        lt = self.dessiner_texte(0,0,"game over", 15, "game_over")
        L, H = self.dimension
        self.move("game_over", (L - lt) / 2, H/2 + 10)
        self.fen.after(5000, lambda : self.delete("game_over"))
    
    def afficher_bravo(self):
        lt = self.dessiner_texte(0,0,"tu es magnifique", 9, "bravo")
        L, H = self.dimension
        self.move("bravo", (L - lt) / 2, H/2 + 10)
        self.fen.after(10000, lambda: self.delete("bravo"))
    
    def __del__(self):
        pass
            
if __name__ == "__main__":
    from tkinter import Tk
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    scene.dessiner_boucliers()
    print(scene.dimension)
    scene.afficher_bravo()
    fen.mainloop()
