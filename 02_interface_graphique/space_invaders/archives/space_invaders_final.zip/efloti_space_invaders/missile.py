# module space_invaders/missile.py

from acteur import Acteur

class Missile(Acteur):
    
    num = 0
    dt = 1000//25
    
    def __init__(self, acteur, image):
        super().__init__(acteur.scene, [image], "missile_", 5)
        self.parent = acteur
        self.marque += str(Missile.num)
        Missile.num += 1
        
    def lancer(self):
        if self.est_hors_scene():
            self.supprimer()
            self.parent.recharger() 
            return
        if not self.vivant: return
        dt = Missile.dt
        self.fen.after(dt, self.lancer)
        self.deplacer(dt/1000)
    
    def toucher(self, acteur):
        if not self.vivant: return
        self.supprimer()
        self.parent.recharger()
    

if __name__ == "__main__":
    from tkinter import Tk
    from affichage import Affichage
    from scene import Scene
    from hero import Hero
    from bouclier import Bouclier
    from random import randint
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    hero = Hero(scene)
    y = 750
    hero.position = (250, 750)
    scene.dessiner_boucliers()
    def mitrailler():
        fen.after(100, mitrailler)
        x = randint(0, scene.dimension[0])
        hero.position = (x, y)
        hero.tirer()
    mitrailler()
    
    fen.mainloop()
