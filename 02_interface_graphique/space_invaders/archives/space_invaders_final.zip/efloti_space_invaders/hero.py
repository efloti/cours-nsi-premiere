# module space_invaders/hero.py

from acteur import Acteur
from image import Image
from missile import Missile
from explosion import Explosion
from bitmaps import missile_hero, explosion_vaisseau, vaisseau
from clavier import Clavier, TOUCHES

class Hero(Acteur):
    
    missile_img = Image(missile_hero)
    explosion_img = Image(explosion_vaisseau)
    
    def __init__(self, scene):
        super().__init__(scene, [Image(vaisseau)], "hero", 4)
        self.clavier = Clavier(self.fen, TOUCHES)
        self.dt = 1000 // 50
        self.peut_tirer = True
        self.surveiller_clavier()
    
    def deplacer(self, duree):
        if not self.vivant or self.en_pause: return
        dx, dy = self.dxy(duree)
        x, y = self.position
        if self.est_dans_scene( (x+dx, y+dy) ):
            self.position = x+dx, y+dy
            self.scene.move(self.marque, dx, dy)
    
    def tirer(self):
        if not self.vivant or self.en_pause: return
        if not self.peut_tirer: return
        self.peut_tirer = False
        x, y = self.position
        l, _ = self.dimension
        m = Missile(self, Hero.missile_img)
        m.vitesse = (0, -500)
        _, hm = m.dimension
        tpx = self.taille_pixel
        m.position = (x+l//(2*tpx) * tpx, y-hm)
        m.afficher()
        m.lancer()
    
    def recharger(self):
        self.peut_tirer = True
    
    def toucher(self, acteur):
        if self.invincible or not self.vivant: return
        self.supprimer()
        Explosion(self)

    def surveiller_clavier(self):
        if not self.vivant: return
        self.fen.after(self.dt, self.surveiller_clavier)
        if self.clavier.est_enfonce('Left'):
            vx, vy = self.vitesse
            self.vitesse = -abs(vx), vy
            self.deplacer(self.dt / 1000)
        elif self.clavier.est_enfonce('Right'):
            vx, vy = self.vitesse
            self.vitesse = abs(vx), vy
            self.deplacer(self.dt / 1000)
        elif self.clavier.est_enfonce('space'):
            self.tirer()
    
    def supprimer(self):
        self.clavier.supprimer()
        super().supprimer()
    
    def __del__(self):
        pass

if __name__ == "__main__":
    from tkinter import Tk
    from scene import Scene
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    h = Hero(scene)
    h.position = 500, 500
    h.vitesse = 500, 0
    h.afficher()
    # ~ fen.after(2000, h.exploser)
    fen.mainloop()
    
