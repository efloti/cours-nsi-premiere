# module space_invaders/bouclier.py

from acteur import Acteur
from missile import Missile
from hero import Hero
from envahisseurs import EnvahisseurFils
from image import Image
from bitmaps import bouclier, masque1, masque2

class Bouclier(Acteur):
    
    num = 0
    masques = [Image(masque1), Image(masque2)]
    
    def __init__(self, scene):
        super().__init__(scene, [Image(bouclier)], "bouclier_", 2)
        self.marque += str(Bouclier.num)
        Bouclier.num += 1
    
    def toucher(self, acteur):
        if isinstance(acteur, Missile):
            _, vy = acteur.vitesse
            if vy < 0:
                xm, _ = acteur.position
                x, y = self.position
                j = int(xm - x) // self.taille_pixel
                i = self.image_courante.get_dernier_bit_en_colonne(j)
                if not i: return
                m = self.masques[1]
                if self.image_courante.suppr_pixel_avec_masque(m, i - m.hauteur + 1, j - m.largeur // 2) > 0:
                    self.effacer()
                    self.afficher()
        
        if isinstance(acteur, EnvahisseurFils):
            pass
    
    def dommage(self, x, y, masque):
        ret = self.get_pixel(x, y)
        if not ret: return
        i, j = ret
        l = self.masque.largeur
        self.image_courante.suppr_pixel_avec_masque(masque, i, j - l//2)
        self.effacer()
        self.afficher()

if __name__ == "__main__":
    from tkinter import Tk
    from scene import Scene
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    b = Bouclier(scene)
    b.position = 250, 250
    b.afficher()
    def clic(evt):
        x, y = evt.x, evt.y
        b.dommage(x, y)
    scene.bind('<1>', clic)
    fen.mainloop()
