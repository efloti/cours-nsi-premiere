# module space_invaders/explosion.py

from acteur import Acteur

class Explosion(Acteur):
    
    num = 0
    
    def __init__(self, acteur):
        super().__init__(acteur.scene, [acteur.explosion_img], "explosion_", acteur.taille_pixel)
        self.marque += str(self.num)
        Explosion.num += 1
        x, y = acteur.position
        self.position = x, y
        self.afficher()
        self.fen.after(1000, self.supprimer)
        self.invincible = True
    
    def toucher(self, acteur):
        pass
    

if __name__ == "__main__":
    from tkinter import Tk, Canvas
    from hero import Hero
    from scene import Scene
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    hero = Hero(scene)
    hero.position = (250, 250)
    Explosion(hero)
    fen.mainloop()
