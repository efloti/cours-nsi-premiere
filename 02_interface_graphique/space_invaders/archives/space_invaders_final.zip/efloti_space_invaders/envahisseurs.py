# module space-invaders/envahisseurs.py

from acteur import Acteur
from image import Image
from bitmaps import envahisseur_mere, envahisseur_fils_1a, envahisseur_fils_1b,\
envahisseur_fils_2a, envahisseur_fils_2b, envahisseur_fils_3a, envahisseur_fils_3b,\
missile1, missile2, explosion_1, explosion_2, explosion_vaisseau
from missile import Missile
from explosion import Explosion
from random import random, randint, choice

class EnvahisseurMere(Acteur):
    
    dt = 1000//25
    explosion_img = Image(explosion_1)
    
    def __init__(self, scene):
        super().__init__(scene, [Image(envahisseur_mere)], "envhr_mere", 4)
        v = 150
        l, h = self.dimension
        L, _ = self.scene.dimension
        if random() > 0.5:
            x = L - 2
            self.vitesse = (-v, 0)
        else:
            x = -l + 2
            self.vitesse = (v, 0)
        self.position = x, 30
        self.points = choice([30, 50, 100, 200, 500, 1000])
        self.afficher()
        self.lancer()
    
    def lancer(self):
        if self.est_hors_scene(): 
            self.supprimer()
            return
        if not self.vivant: return
        dt = EnvahisseurMere.dt
        self.idtimer = self.scene.after(dt, self.lancer)
        # ~ print(self.en_pause)
        self.deplacer(dt / 1000)
    
    def toucher(self, autre):
        self.supprimer()
        Explosion(self)
    

class EnvahisseurFils(Acteur):
    missile_imgs = [Image(missile1), Image(missile2)]
    explosion_imgs = [Image(explosion_1), Image(explosion_2)]
    
    def __init__(self, scene, images, marque, meute):
        super().__init__(scene, images, "envhr_fils_", 4)
        self.marque += marque
        self.meute = meute
    
    def deplacer(self, dx, dy):
        if not self.vivant or self.en_pause: return
        x, y = self.position
        self.position = x + dx, y + dy
        self.scene.move(self.marque, dx, dy)
        self.image_suivante()
    
    def tirer(self):
        if not self.vivant or self.en_pause: return
        x, y = self.position
        l, h = self.dimension
        m = Missile(self, self.missile_imgs[randint(0, 1)])
        lm, _ = m.dimension
        m.vitesse = (0, 300)
        m.position = x + l/2 - lm/2, y + h
        m.afficher()
        m.lancer()
    
    def toucher(self, autre):
        if not isinstance(autre, Missile): return
        *_, i, j = self.marque.split('_')
        i, j = int(i), int(j)
        self.meute.supprimer_individu(i, j)
        self.supprimer()
        self.exploser()
    
    def exploser(self):
        self.explosion_img = self.explosion_imgs[randint(0,1)]
        Explosion(self)
    
    def pause(self):
        self.en_pause = not self.en_pause
        self.meute.en_pause = self.en_pause

class EnvahisseurFils1(EnvahisseurFils):
    
    def __init__(self, scene, marque, meute):
        super().__init__(scene, [Image(envahisseur_fils_1a), Image(envahisseur_fils_1b)], "1_", meute)
        self.marque += marque
        self.points = 30

class EnvahisseurFils2(EnvahisseurFils):
    
    def __init__(self, scene, marque, meute):
        super().__init__(scene, [Image(envahisseur_fils_2a), Image(envahisseur_fils_2b)], "2_", meute)
        self.marque += marque
        self.points = 20

class EnvahisseurFils3(EnvahisseurFils):
    
    def __init__(self, scene, marque, meute):
        super().__init__(scene, [Image(envahisseur_fils_3a), Image(envahisseur_fils_3b)], "3_", meute)
        self.marque += marque
        self.points = 10
    
if __name__ == "__main__":
    from tkinter import Tk
    from scene import Scene
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    e1 = EnvahisseurMere(scene)
    x, y, dx = 50, 600, 150
    for Env in [EnvahisseurFils1, EnvahisseurFils2, EnvahisseurFils3]:
        e = Env(scene, "test", None)
        e.position = x, y
        e.afficher()
        e.tirer()
        fen.after(2000, e.supprimer)
        x += dx
    fen.mainloop()
