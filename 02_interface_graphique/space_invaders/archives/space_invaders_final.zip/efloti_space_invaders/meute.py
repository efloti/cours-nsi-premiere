# module space-invaders/envahisseurs.py

from envahisseurs import EnvahisseurFils1, EnvahisseurFils2, EnvahisseurFils3
from image import Image
from random import randint

class Meute:
    
    NB_LIGNE = 5 #5
    NB_COL = 10 #12
    
    def __init__(self, scene):
        self.fen = scene.fen
        self.scene = scene
        self.nb_env = self.NB_LIGNE * self.NB_COL
        self.position = (100, 100)# (100, 100)
        self.taille_pixel = 4
        self.largeur_maille = self.taille_pixel * 16
        self.hauteur_maille = self.taille_pixel * 14
        self.matrice = self.init_matrice()
        self.dt = 600
        self.dx = 15
    
        self.en_pause = False
    
    def set_dt(self, dt):
        self.dt = dt
        
    def init_matrice(self):
        mat = []
        x0, y0 = self.position
        L = self.largeur_maille
        H = self.hauteur_maille
        for i in range(Meute.NB_LIGNE):
            y = y0 + H * i
            ligne = []
            if i == 0:
                Env = EnvahisseurFils1
            elif i in [1, 2]:
                Env = EnvahisseurFils2
            else:
                Env = EnvahisseurFils3
            for j in range(Meute.NB_COL):
                x = x0 + L * j
                env = Env(self.scene, f"{i}_{j}", self)
                l, h = env.dimension
                x1 = x + (L - l) // 2
                y1 = y + (H - h) // 2
                env.position = (x1, y1)
                ligne.append(env)
            mat.append(ligne)
        return mat
    
    def afficher(self):
        for l in self.matrice:
            for env in l:
                if env:
                    env.afficher()
            
    def effacer(self):
        for l in self.matrice:
            for env in l:
                if env:
                    env.effacer()
    
    def deplacer(self, dx, dy):
        if self.en_pause: return
        x, y = self.position
        self.position = x + dx, y + dy
        for l in self.matrice:
            for env in l:
                if env:
                    env.deplacer(dx, dy)
    
    def get_last_in_col(self, j):
        dernier = None
        for i in range(self.NB_LIGNE):
            if self.matrice[i][j]:
                dernier = i
        return dernier
    
    def get_xmax(self):
        x, _ = self.position
        return  x + Meute.NB_COL * self.largeur_maille
        
    def lancer(self):
        if self.nb_env == 0: return
        self.fen.after(self.dt, self.lancer)
        if self.en_pause: return 
        dx = self.dx
        x, _ = self.position
        L, _ = self.scene.dimension
        xmax = self.get_xmax()
        if xmax + dx > L:
            self.deplacer(0, self.hauteur_maille)
            self.dx = -dx
        elif x + dx < 0:
            self.deplacer(0, self.hauteur_maille)
            self.dx = -dx
        else:
            self.deplacer(dx, 0)

    def tirer(self):
        if self.nb_env == 0: return
        self.fen.after(randint(300, 1300), self.tirer)
        if self.en_pause: return
        env = None
        while env == None:
            j = randint(0, Meute.NB_COL-1)
            i = self.get_last_in_col(j)
            if i is not None:
                env = self.matrice[i][j]
        env.tirer()
        
    def pause(self, evt):
        self.en_pause = not self.en_pause
    
    def supprimer_individu(self, i, j):
        env = self.matrice[i][j]
        if env:
            self.nb_env -= 1
            env.supprimer()
            self.matrice[i][j] = None
        if self.nb_env == 0:
            self.scene.fin_meute()
    
    def __del__(self):
        pass
    

if __name__ == "__main__":
    from tkinter import Tk
    from scene import Scene
    fen = Tk()
    scene = Scene(fen)
    scene.pack()
    m = Meute(scene)
    m.afficher()
    m.lancer()
    m.tirer()
    fen.mainloop()
