# module space_invaders/missile.py
from scene import fen, scene, LARGEUR, HAUTEUR

def initialiser_missile(x, y, largeur=5, hauteur=15, couleur="white"):
    _id = scene.create_rectangle(x, y, x+largeur, y+hauteur, fill=couleur)
    return {
        "id": _id,
        "largeur": largeur,
        "hauteur": hauteur,
        "position": (x, y),
        "vitesse": 0 # en pixels par seconde
    }

def set_vitesse(fig, v):
    fig["vitesse"] = v

def lancer(fig):
    v = fig["vitesse"]
    # si la vitesse est nulle, inutile de continuer
    if v == 0: return

    # déplacement pour 50 ms
    dy = v / 20

    x, y = fig["position"]
    largeur, hauteur = fig["largeur"], fig["hauteur"]

    # si le missile est sorti de la scene (entièrement) le détruire
    if x > LARGEUR or x + largeur < 0 or y > HAUTEUR or y + hauteur < 0:
        supprimer(fig)
        # attention à utiliser return pour mettre fin à la fonction! sinon...
        return

    # à présent, on peut agir ...
    scene.move(fig["id"], 0, dy)
    # ne pas oublier de mettre à jour
    fig["position"] = x, y + dy

    # et on recommence
    fen.after(50, lambda: lancer(fig))

def supprimer(fig):
    # désallouer ressouce graphique
    scene.delete(fig["id"])
    # désallouer le dictionnaire
    del fig

if __name__ == "__main__":
    from random import randint
    missiles = []
    for _ in range(30):
        m = initialiser_missile(randint(0, LARGEUR), HAUTEUR - 30)
        missiles.append(m)
    for m in missiles:
        set_vitesse( m, -randint(50, 300) )
    fen.bind( '<space>', lambda evt: lancer( missiles.pop() ) )
    fen.mainloop()
