from scene import fen, scene, LARGEUR, HAUTEUR

def initialiser_rect(x, y, largeur=50, hauteur=30, couleur="white"):
    rect = scene.create_rectangle(x, y, x+largeur, y+hauteur, fill=couleur)
    return {
        "id": rect,
        "largeur": largeur,
        "hauteur": hauteur,
        "position": (x, y),
        "vitesse": 0 # en pixels par seconde
    }

def gauche(fig):
    x, y = fig["position"]
    if x - 5 >= 0:
        scene.move(fig["id"], -5, 0)
        # attention à mettre jour la figure!
        fig["position"] = x - 5, y

def droite(fig):
    x, y = fig["position"]
    largeur = fig["largeur"]
    if x + largeur + 5 <= LARGEUR:
        scene.move(fig["id"], 5, 0)
        fig["position"] = x + 5, y

def reagir(fig, evt_type, gestionnaire):
    # pourquoi a-t-on besoin d'une fonction lambda ici?
    fen.bind(evt_type, lambda evt: gestionnaire(fig))

def set_vitesse(fig, v):
    fig["vitesse"] = v

def lancer(fig):
    v = fig["vitesse"]
    # si la vitesse est nulle, inutile de continuer
    if v == 0: return

    # déplacement pour 50ms
    dx = v // 20

    # doit-on changer de direction ?
    x, y = fig["position"]
    largeur = fig["largeur"]
    if x + largeur + dx > LARGEUR and v > 0 or x - dx < 0 and v < 0:
        # on change de direction!    
        fig["vitesse"] = -v
        dx = -dx

    # à présent, on peut agir ...
    scene.move(fig["id"], dx, 0)
    # ne pas oublier de mettre à jour
    fig["position"] = x + dx, y

    # et on recommence
    fen.after(50, lambda: lancer(fig))    

if __name__ == "__main__":
    rect = initialiser_rect(450, 300)
    set_vitesse(rect, 80)
    lancer(rect)
    fen.mainloop()
