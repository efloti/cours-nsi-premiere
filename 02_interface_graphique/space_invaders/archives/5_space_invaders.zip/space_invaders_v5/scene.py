# module space_invaders/scene.py
from tkinter import Tk, Canvas

fen = Tk()
fen.title("space invaders")

class Scene(Canvas):

    def __init__(self, fen):
        super().__init__(fen, width=1000, height=800, bg="black")
        # un «ensemble» - set - pour suivre les acteurs
        self.acteurs = set()

        self.gerer_collision()

    def creer_acteur(self, acteur):
        xmin, ymin, xmax, ymax = acteur.min_max()
        if acteur.image is not None:
            _id = self.create_image(xmin, ymin, image=acteur.image, anchor="nw")
        else:
            _id = self.create_rectangle(xmin, ymin, xmax, ymax, fill=acteur.couleur, width=0)
        # mémorisons cet acteur
        self.acteurs.add(acteur)
        return _id

    def supprimer_acteur(self, acteur):
        # suppression de l'item graphique
        self.delete(acteur.id)
        # suppression des acteurs en scène
        self.acteurs.discard(acteur)

    def est_en_collision(self, acteur1, acteur2):
        """renvoie True ou False selon que les acteurs sont en collision
        (se recouvrent partiellement) ou non."""

        assert acteur1 is not acteur2

        x1_min, y1_min, x1_max, y1_max = acteur1.min_max()
        x2_min, y2_min, x2_max, y2_max = acteur2.min_max()

        # horizontalement
        # si l'acteur1 est à gauche de l'acteur2
        # ou si c'est le contraire, pas de collision
        if x1_max <= x2_min or x2_max <= x1_min:
            return False

        # verticalement
        if y1_max <= y2_min or y2_max <= y1_min:
            return False

        # dans tous les autres cas: collision!
        return True


    def gerer_collision(self, delai_milli=50):
        # un ensemble pour collecter les acteurs en collision
        a_supprimer = set()

        for acteur1 in self.acteurs:
            # si cet acteur est dans a_supprimer
            # inutile de s'en occuper! 
            if acteur1 in a_supprimer: continue

            for acteur2 in self.acteurs:
                # si acteur2 est identique à acteur1 ou
                # si il est déjà dans a_supprimer,
                #inutile de s'en occuper!
                if acteur1 is acteur2 or acteur2 in a_supprimer: continue
                
                # sont-ils en collision ?
                if self.est_en_collision(acteur1, acteur2):
                    # si oui, on les collecte
                    a_supprimer.add(acteur1)
                    a_supprimer.add(acteur2)

        # suppression des acteurs collectés
        for a in a_supprimer:
            a.supprimer()

        # ne pas oublier de relancer
        self.after(50, self.gerer_collision)

scene = Scene(fen)
scene.pack()

if __name__ == "__main__":
    # Regarder la console...
    fen.mainloop()
