from tableau import Tableau
from envahisseurs import EnvahisseurFils
from random import choice, randint

class Meute:
    def __init__(self, scene, nb_lignes=3, nb_colonnes=5, largeur_case=70, hauteur_case=70):
        # attributs généraux
        self.scene = scene
        self.nb_lignes = nb_lignes
        self.nb_colonnes = nb_colonnes
        self.largeur_case = largeur_case
        self.hauteur_case = hauteur_case
        
        self.tableau = Tableau(nb_lignes, nb_colonnes)
        self.pos = 0, 0
        
        # gestion du déplacement
        self.pas = 20 # en pixel
        self.delai = 500 # durée entre deux pas en milliseconde
        
        # remplissons les cases de la meute
        # dont la position est x=0 et y=0
        for i in range(nb_lignes):
            for j in range(nb_colonnes):
                # coordonnées de la case i, j
                x_case = j * largeur_case
                y_case = i * hauteur_case
                
                # centrons l'envahisseur dans sa case
                env = EnvahisseurFils(scene, self)
                l, h = env.dim
                x_env = x_case + (largeur_case-l)/2
                y_env = y_case + (hauteur_case-h)/2               
                env.set_position(x_env, y_env)
                
                # il est temps de l'ajouter au tableau sous jacent
                self.tableau.ajouter(env, i, j)
        
    def supprimer_acteur(self, acteur):
        self.tableau.supprimer_valeur(acteur)
    
    def deplacer(self, dx, dy):
        if self.tableau.est_vide(): return
        
        x, y = self.pos
        self.pos = x + dx, y + dy
        for env in self.tableau.liste_valeurs():
            env.deplacer(dx, dy)

    def tirer(self):
        if self.tableau.est_vide(): return

        tireurs = self.tableau.frontiere_basse()
        tireur = choice(tireurs)
        tireur.tirer()
    
    def attaquer(self):
        if self.tableau.est_vide(): return
        self.tirer()
        self.scene.after(randint(400, 1000), self.attaquer)
    
    def min_max(self):
        pass
    
    def lancer(self):
        if self.tableau.est_vide(): return
        xmin, ymin = self.pos
        xmax = xmin + self.nb_colonnes * self.largeur_case
        if xmin + self.pas < 0 or xmax + self.pas > int(self.scene["width"]):
            self.deplacer(0, self.hauteur_case)
            self.pas = - self.pas
        else:
            self.deplacer(self.pas, 0)
        self.scene.after(self.delai, self.lancer)
    
    # Pour s'assurer que la meute est détruite par Python
    # lorsqu'elle ne contient plus aucun envahisseur.
    def __del__(self):
        print("Mort de la meute")

if __name__ == "__main__":
    from scene import *
    from hero import Hero
    from envahisseurs import EnvahisseurMere
    m = Meute(scene, 3, 3)
    m.deplacer(0, 100)
    m.attaquer()
    m.lancer()
    EnvahisseurMere(scene)
    Hero(scene)
    del m
    fen.mainloop()
