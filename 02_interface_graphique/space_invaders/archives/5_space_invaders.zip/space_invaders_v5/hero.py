from acteur import Acteur
from missile import Missile
from tkinter import PhotoImage

# ~ hero_img = PhotoImage(file="img/hero.png")

class Hero(Acteur):
    
    def __init__(self, scene):
        super().__init__(scene, image=PhotoImage(file="images/hero.png"))
        
        self._left = self.reagir('<Left>', self.gauche)
        self._right = self.reagir('<Right>', self.droite)
        self._space = self.reagir('<space>', self.tirer)
        
        self.pas = 10
        self.set_position(self.L//2, self.H-50)
        
    def supprimer(self):
        super().supprimer()
        self.fen.unbind('<space>', self._space)
        self.fen.unbind('<Right>', self._right)
        self.fen.unbind('<Left>', self._left)
    
    def gauche(self):
        if self.est_dans_scene(-self.pas, 0):
            self.deplacer(-self.pas, 0)
    
    def droite(self):
        if self.est_dans_scene(self.pas, 0):
            self.deplacer(self.pas, 0)
    
    def tirer(self):
        m = Missile(self.scene)
        x_min, y_min, x_max, y_max = self.min_max()
        xm_min, ym_min, xm_max, ym_max = m.min_max()
        m.set_position(
            (x_min+x_max)/2 - (xm_max - xm_min)/2,
             y_min-(ym_max-ym_min)
        )
        m.set_vitesse(-500)
        m.lancer()
    
if __name__ == "__main__":
    from scene import *
    Hero(scene)
    fen.mainloop()
