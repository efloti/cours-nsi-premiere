def min_max(liste, null=None):
    N = len(liste)
    imin = 0
    imax = N - 1
    while imin < N and liste[imin] == null:
        imin += 1
    while imax >= 0 and liste[imax] == null:
        imax -= 1
    return imin, imax

class Grille:

    def __init__(self, nb_lignes=5, nb_colonnes=10):
        self._grille = []
        for i in range(nb_lignes):
            ligne = []
            for j in range(nb_colonnes):
                ligne.append(None)
            self._grille.append(ligne)
        
        self.nb_lignes = nb_lignes
        self.nb_colonnes = nb_colonnes
        
        self._nb_de_valeur = 0
        self._lmin = None
        self._lmax = None
        self._cmin = None
        self._cmax = None
    
    def ajouter(self, val, ligne, col):
        assert 0<= ligne < self.nb_lignes and 0 <= col < self.nb_colonnes
        if self._grille[ligne][col] is not None:
            return
            
        if self._nb_de_valeur == 0:
            self._lmin = ligne
            self._lmax = ligne
            self._cmin = col
            self._cmax = col
            
        if ligne < self._lmin:
            self._lmin = ligne
        if ligne > self._lmax:
            self._lmax = ligne
        
        if col < self._cmin:
            self._cmin = col
        if col > self._cmax:
            self._cmax = col
        
        self._grille[ligne][col] = val
        self._nb_de_valeur += 1
    
    def supprimer(self, ligne, col):
        assert 0<= ligne < self.nb_lignes and 0 <= col < self.nb_colonnes
        if self._grille[ligne][col] is None:
            return
        
        self._grille[ligne][col] = None
        self._nb_de_valeur -= 1
        
        if self._nb_de_valeur == 0:
            self._lmin = None
            self._lmax = None
            self._cmin = None
            self._cmax = None
            return
        
        if not (self._lmin < ligne < self._lmax):
            self._lmin, self._lmax = self.min_max_ligne()
        if not (self._cmin < col < self._cmax):
            self._cmin, self._cmax = self.min_max_colonne()
    
    def supprimer_valeur(self, valeur):
        a_supprimer = []
        for i in range(self.nb_lignes):
            for j in range(self.nb_colonnes):
                if self._grille[i][j] is valeur:
                    a_supprimer.append((i, j))
        
        for i, j in a_supprimer:
            self.supprimer(i, j)
    
    def frontiere_basse(self):
        collecte = []
        for j in range(self.nb_colonnes):
            col = self.get_colonne(j)
            imin, imax = min_max(col)
            if imin > imax: continue
            collecte.append(col[imax])
        return collecte
    
    def liste_valeurs(self):
        valeurs = []
        for i in range(self.nb_lignes):
            for j in range(self.nb_colonnes):
                v = self._grille[i][j]
                if v is not None:
                    valeurs.append(v)
        return valeurs
    
    def min_max_ligne(self):
        lmin, lmax = min_max(self.get_colonne(0))
        for j in range(1, self.nb_colonnes):
            l_min, l_max = min_max(self.get_colonne(j))
            if l_min < lmin:
                lmin = l_min
            if l_max > lmax:
                lmax = l_max
        
        return lmin, lmax
        
    def min_max_colonne(self):
        cmin, cmax = min_max(self.get_ligne(0))
        for i in range(1, self.nb_lignes):
            c_min, c_max = min_max(self.get_ligne(i))
            if c_min < cmin:
                cmin = c_min
            if c_max > cmax:
                cmax = c_max
        return cmin, cmax
            
    def get_ligne(self, ligne):
        assert 0 <= ligne < self.nb_lignes
        return self._grille[ligne]
    
    def get_colonne(self, col):
        assert 0 <= col < self.nb_colonnes
        ret = []
        for ligne in self._grille:
            ret.append(ligne[col])
        return ret
    
    def _est_vide(self, ligne_ou_col):
        for valeur in ligne_ou_col:
            if valeur == 1:
                return False
        return True
    
    def get_index_der_col(self):
        return self._cmax
    
    def get_index_prem_col(self):
        return self._cmin
    
    def get_index_prem_ligne(self):
        return self._lmin
    
    def get_index_der_ligne(self):
        return self._lmax
    
    def get_min_max(self):
        return self._lmin, self._cmin, self._lmax, self._cmax
    
    def est_vide(self):
        return self._nb_de_valeur == 0
    
    def __str__(self):
        return "\n".join([str(l) for l in self._grille])

if __name__ == "__main__":
    # ~ print(min_max([None, None, None]))
    g = Grille(5, 5)
    g.ajouter(1,2,3)
    g.ajouter(1,4,0)
    g.ajouter(1,2,4)
    g.supprimer(2,4)
    print(g)
    print(g.get_min_max())
    g.ajouter(1,0,1)
    g.supprimer(4, 0)
    print(g.get_min_max())
    print(g.frontiere_basse())
    g.ajouter(2, 3, 3)
    print(g.frontiere_basse())
    print(g)
    g.supprimer_valeur(1)
    print(g)
    print(g._nb_de_valeur)

