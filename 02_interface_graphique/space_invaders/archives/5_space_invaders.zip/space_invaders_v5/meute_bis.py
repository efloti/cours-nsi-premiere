from grille import Grille
from envahisseurs import EnvahisseurFils
from random import choice, randint

class Meute:
    def __init__(self, scene, nb_lignes=3, nb_colonnes=5, largeur_case=70, hauteur_case=70):
        
        self.scene = scene
        self.nb_lignes = nb_lignes
        self.nb_colonnes = nb_colonnes
        self.largeur_case = largeur_case
        self.hauteur_case = hauteur_case
        
        self._grille = Grille(nb_lignes, nb_colonnes)
        self.pos = 0, 0
        self.pas = 20
        self.delai = 500
        self._annul1 = None
        self._annul2 = None
        
        x, y = 0, 0
        for i in range(nb_lignes):
            x = 0
            for j in range(nb_colonnes):
                env = EnvahisseurFils(scene, self)
                l, h = env.dim
                xenv = x + (largeur_case-l)/2
                yenv = y + (hauteur_case-h)/2
                env.set_position(xenv, yenv)
                self._grille.ajouter(env, i, j)
                
                x += largeur_case
            
            y += hauteur_case
        
    def supprimer_acteur(self, acteur):
        self._grille.supprimer_valeur(acteur)
        if self._grille.est_vide():
            self.scene.after_cancel(self._annul1)
            self.scene.after_cancel(self._annul2)
    
    def deplacer(self, dx, dy):
        x, y = self.pos
        self.pos = x + dx, y + dy
        for env in self._grille.liste_valeurs():
            env.deplacer(dx, dy)

    def tirer(self):
        env = choice(self._grille.frontiere_basse())
        env.tirer()
    
    def attaquer(self):
        self._annul2 = self.scene.after(randint(200, 800), self.attaquer)
        if not self._grille.est_vide():
            self.tirer()
    
    def min_max(self):
        x, y = self.pos
        imin, jmin, imax, jmax = self._grille.get_min_max()
        xmin = x + jmin * self.largeur_case
        xmax = x + (jmax + 1) * self.largeur_case
        ymin = y + imin * self.hauteur_case
        ymax = y + (imax + 1) * self.hauteur_case
        return xmin, ymin, xmax, ymax
    
    def lancer(self):
        self._annul1 = self.scene.after(self.delai, self.lancer)
        xmin, ymin, xmax, ymax = self.min_max()
        if xmin + self.pas < 0 or xmax + self.pas > int(self.scene["width"]):
            self.deplacer(0, self.hauteur_case)
            self.pas = - self.pas
            return
        self.deplacer(self.pas, 0)
    
    def __del__(self):
        print("Mort de la meute")
        
if __name__ == "__main__":
    from scene import *
    from hero import Hero
    from envahisseurs import EnvahisseurMere
    m = Meute(scene, 3, 3)
    m.deplacer(0, 100)
    m.lancer()
    m.attaquer()
    del m
    Hero(scene)
    EnvahisseurMere(scene)
    fen.mainloop()
