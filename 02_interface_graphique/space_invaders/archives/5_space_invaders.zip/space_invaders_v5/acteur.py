# module space_invaders/acteur.py
class Acteur:
    
    def __init__(self, scene, largeur=100, hauteur=100, couleur="white", image=None):
        self.scene = scene
        self.fen = scene.winfo_toplevel()
        self.L = int(scene["width"])
        self.H = int(scene["height"])
        
        self.image = image
        if image is not None:
            self.dim = image.width(), image.height()
        else:
            self.dim = largeur, hauteur
        self.pos = 0, 0
        self.v = 0 # vitesse en pixel par seconde
        self.couleur = couleur
        
        
        self.id = scene.creer_acteur(self)
    
    def supprimer(self):
        "Efface l'acteur de la scene"
        
        self.scene.supprimer_acteur(self)
    
    def set_position(self, x, y):
        "Met l'acteur dans la position indiquée"
        
        x0, y0 = self.pos
        self.pos = x, y
        self.scene.move(self.id, x-x0, y-y0)
    
    def deplacer(self, dx, dy):
        "Déplace l'acteur de dx pixels horizontalement et de dy pixels verticalement"
        
        x0, y0 = self.pos
        self.set_position(x0+dx, y0+dy)
 
    def deplacer_duree(self, duree, direction="h"):
        """Déplace l'acteur en utilisant sa vitesse (horizontalement par défaut)
        «duree» est supposée être en seconde
        """
        
        if direction == "h":
            dx = self.v * duree
            self.deplacer(dx, 0)
        else:
            dy = self.v * duree
            self.deplacer(0, dy)
    
    def set_vitesse(self, v):
        self.v = v

    def reagir(self, evt_type, gestionnaire):
        return self.fen.bind(evt_type, lambda _: gestionnaire())
    
    def est_hors_scene(self):
        """Test si l'acteur est entièrement hors de la scène"""
        
        xmin, ymin, xmax, ymax = self.min_max()
        return xmax < 0 or xmin >= self.L or ymax < 0 or ymin >= self.H
    
    def est_dans_scene(self, dx=0, dy=0):
        """Test si l'acteur est entièrement dans la scène,
        après un déplacement (virtulel) dx, dy s'il est précisé"""
        
        xmin, ymin, xmax, ymax = self.min_max()
        return xmin + dx >= 0 and xmax + dx <= self.L and ymin + dy >= 0 and ymax + dy <= self.H
    
    def min_max(self):
        """renvoie xmin, ymin, xmax, ymax"""
        x, y = self.pos
        l, h = self.dim
        return x, y, x + l, y + h
    
    def __del__(self):
        print(self, " supprimer!")
    

if __name__ == "__main__":
    # zone pour tester son code
    from scene import *
    acteur = Acteur(scene)
    acteur.set_position(acteur.L - 50, 100)
    # testons les fonctions modifiées avec min_max
    print("dans scene?", acteur.est_dans_scene())
    print("hors scene?", acteur.est_hors_scene())
    acteur.reagir("<Left>", lambda : acteur.deplacer(-5, 0) )
    acteur.reagir("<Right>", lambda : acteur.deplacer(5, 0) )
    fen.mainloop()
