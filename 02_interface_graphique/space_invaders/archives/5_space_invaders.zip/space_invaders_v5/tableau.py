
def index_derniere_valeur(liste):
    N = len(liste)
    i = N - 1 # index du dernier élément de liste
    
    while i >= 0 and liste[i] == None:
        i -= 1
    
    return i

class Tableau:
    def __init__(self, nb_lignes, nb_colonnes):
        self.nb_lignes = nb_lignes
        self.nb_colonnes = nb_colonnes
        self.nb_valeurs = 0
        
        # amorçage de la liste de liste qui représente le tableau
        tableau = []
        for i in range(nb_lignes):
            # construction de la ligne i
            ligne = []
            for j in range(nb_colonnes):
                ligne.append(None)
            
            # ajout de la ligne au tableau
            tableau.append(ligne)
        
        self.tableau = tableau
    
    def ajouter(self, valeur, i, j):
        "ajoute valeur dans la case i,j si elle est vide"
        assert 0 <= i < self.nb_lignes and 0 <= j < self.nb_colonnes
        
        if self.tableau[i][j] is not None: return
    
        self.tableau[i][j] = valeur
        self.nb_valeurs += 1
    
    def supprimer(self, i, j):
        "supprime la valeur de la case i,j"
        assert 0 <= i < self.nb_lignes and 0 <= j < self.nb_colonnes
        
        self.tableau[i][j] = None
        self.nb_valeurs -=1
    
    def supprimer_valeur(self, valeur):
        "supprimer valeur du tableau si elle y figure"
        a_supprimer = []
        for i in range(self.nb_lignes):
            for j in range(self.nb_colonnes):
                v = self.tableau[i][j]
                if valeur is v or valeur == v:
                    a_supprimer.append( (i, j) )
    
        for i, j in a_supprimer:
            self.supprimer(i, j)
    
    def ligne(self, i):
        "renvoie la ligne i"
        assert 0 <= i < self.nb_lignes
        return self.tableau[i]
    
    def colonne(self, j):
        "renvoie une liste qui correspond à la colonne j"
        assert 0 <= j < self.nb_colonnes
        
        col = []
        for i in range(self.nb_lignes):
            col.append(self.tableau[i][j])
        
        return col

    def liste_valeurs(self):
        "renvoie la liste des valeurs différente de None"
        valeurs = []
        for i in range(self.nb_lignes):
            for j in range(self.nb_colonnes):
                v = self.tableau[i][j]
                if v is not None:
                    valeurs.append(v)
        
        return valeurs
    
    def frontiere_basse(self):
        "renvoie la liste des valeurs qui sont les dernières de leur colonne"
        fr_basse = []
        for j in range(self.nb_colonnes):
            col = self.colonne(j)
            index = index_derniere_valeur(col)
            if index >= 0:
                v = col[index]
                fr_basse.append(v)
        
        return fr_basse
    
    def jmin_max(self):
        "renvoie les numéros des colonnes frontières gauche et droite"
        pass
    
    def est_vide(self):
        return self.nb_valeurs == 0
