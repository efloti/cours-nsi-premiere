from acteur import Acteur
from missile import Missile
from random import choice
from tkinter import PhotoImage

class EnvahisseurMere(Acteur):
    
    def __init__(self, scene):
        super().__init__(scene, image=PhotoImage(file="images/env_mere.png"))
        # choisir une vitesse au hasard
        self.v = choice([-100, 100])
        self._annul = None
        
        # régler la position de façon à apparaîte en haut
        # à gauche ou à droite selon la vitesse ...
        l, _ = self.dim
        if self.v > 0:
            self.set_position(-l+10, 30)
        else:
            self.set_position(self.L-10, 30)
        
        # tout est prêt! lançons le.
        self._lancer()

    def supprimer(self):
        super().supprimer()
        self.scene.after_cancel(self._annul)

    def _lancer(self, duree_milli=50):
        if self.est_hors_scene():
            self.supprimer()
            return
        
        self.deplacer_duree(duree_milli / 1000)
        
        self._annul = self.scene.after(
            duree_milli,
            lambda: self._lancer(duree_milli),
        )


class EnvahisseurFils(Acteur):
    
    def __init__(self, scene, meute):
        super().__init__(scene, image=PhotoImage(file="images/env_fils.png"))
        self.meute = meute
    
    def supprimer(self):
        super().supprimer()
        self.meute.supprimer_acteur(self)
    
    def tirer(self):
        x, y = self.pos
        l, h = self.dim
        m = Missile(self.scene)
        m.set_position(x + l//2, y + h)
        m.set_vitesse(300)
        m.lancer()

if __name__ == "__main__":
    from scene import *
    from hero import Hero
    EnvahisseurMere(scene)
    Hero(scene)
    fen.mainloop()
