# module space_invaders/missile.py
from scene import fen, scene, LARGEUR, HAUTEUR

class Missile:
    
    def __init__(self, x, y, largeur=5, hauteur=15, couleur="white"):
        _id = scene.create_rectangle(x, y, x+largeur, y+hauteur, fill=couleur)
        
        self.id = _id
        self.dim = largeur, hauteur
        self.pos = x, y
        self.v = 0 # en pixels par seconde
    
    def __del__(self):
        # désallouer ressouce graphique
        print('boum!')
        scene.delete(self.id)
    
    def set_vitesse(self, v):
        self.v = v
    
    def lancer(self):
        v = self.v
        # si la vitesse est nulle, inutile de continuer
        if v == 0: return

        # déplacement pour 100ms
        dy = v / 20

        x, y = self.pos
        largeur, hauteur = self.dim

        # si le missile est sorti de la scene (entièrement) le détruire
        if x > LARGEUR or x + largeur < 0 or y > HAUTEUR or y + hauteur < 0:
            del self
            # attention à utiliser return pour mettre fin à la fonction! sinon...
            return

        # à présent, on peut agir ...
        scene.move(self.id, 0, dy)
        # ne pas oublier de mettre à jour
        self.pos = x, y + dy

        # et on recommence
        fen.after(50, lambda: self.lancer())

if __name__ == "__main__":
    from random import randint
    missiles = []
    for _ in range(5):
        m = Missile(randint(0, LARGEUR), HAUTEUR - 30)
        missiles.append(m)
    for m in missiles:
        m.set_vitesse(-randint(50, 300))
    fen.bind( '<space>', lambda evt: (missiles.pop()).lancer() )
    fen.mainloop()
