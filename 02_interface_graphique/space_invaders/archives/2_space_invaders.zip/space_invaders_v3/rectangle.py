from scene import fen, scene, LARGEUR, HAUTEUR

class Hero:
    
    def __init__(self, x, y, largeur=50, hauteur=30, couleur="white"):
        rect = scene.create_rectangle(x, y, x+largeur, y+hauteur, fill=couleur)
        
        self.id = rect
        self.dim = largeur, hauteur
        self.pos = x, y
        self.v = 0 # en pixels par seconde
    
    def gauche(self):
        x, y = self.pos # fig["position"]
        if x - 5 >= 0:
            scene.move(self.id, -5, 0)
            # attention à mettre jour la figure!
            self.pos = x - 5, y
    
    def droite(self):
        x, y = self.pos
        l, h = self.dim
        if x + l + 5 <= LARGEUR:
            scene.move(self.id, 5, 0)
            self.pos = x + 5, y
    
    def reagir(self, evt_type, gestionnaire):
        fen.bind(evt_type, lambda evt: gestionnaire(self))
    
    def set_vitesse(self, v):
        self.v = v
    
    def lancer(self):
        v = self.v
        # si la vitesse est nulle, inutile de continuer
        if v == 0: return

        # déplacement pour 100ms
        dx = v // 20

        # doit-on changer de direction ?
        x, y = self.pos
        l, h = self.dim
        if x + l + dx > LARGEUR and v > 0 or x - dx < 0 and v < 0:
            # on change de direction!    
            self.v = -v
            dx = -dx

        # à présent, on peut agir ...
        scene.move(self.id, dx, 0)
        # ne pas oublier de mettre à jour
        self.pos = x + dx, y
        
        # et on recommence
        fen.after(50, lambda: self.lancer())

if __name__ == "__main__":
    hero = Hero(450, 300) # initialiser_rect(450, 300)
    hero.set_vitesse(80)
    hero.lancer()
    fen.mainloop()
