# module space_invaders/scene.py
from tkinter import Tk, Canvas
LARGEUR, HAUTEUR = 1000, 500

fen = Tk()
fen.title("space invaders")
scene = Canvas(fen, width=LARGEUR, height=HAUTEUR, bg="black")
scene.pack()

def message():
    print("hello")
    # on peut mentionner une fonction à l'intérieur d'elle même!
    fen.after(2000, message)

if __name__ == "__main__":
    # Regarder la console...
    fen.after(3000, message)
    print("c'est parti!")
    fen.mainloop()
