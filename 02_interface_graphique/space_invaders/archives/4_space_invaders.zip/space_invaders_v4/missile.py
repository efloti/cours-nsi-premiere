# module space_invaders/missile.py
from acteur import Acteur

class Missile(Acteur):
    def __init__(self, scene, couleur="white"):
        super().__init__(scene, largeur=5, hauteur=15, couleur=couleur)

    def lancer(self, duree_milli=50):
        # si le missile est sorti de la scène (entièrement) le détruire
        if self.est_hors_scene():
            self.supprimer()
            # attention à utiliser return pour mettre fin à la fonction! sinon...
            return

        # à présent, on peut agir ...
        self.deplacer_duree(duree_milli / 1000, "v")

        # et on recommence
        self.fen.after(duree_milli, lambda: self.lancer(duree_milli))

if __name__ == "__main__":
    from scene import *
    from random import randint
    
    missiles = []
    for _ in range(5):
        m = Missile(scene)
        m.set_position(randint(0, 1000), 770)
        missiles.append(m)
    
    for m in missiles:
        m.set_vitesse(-randint(50, 300))
    del m
    fen.bind( '<space>', lambda evt: (missiles.pop()).lancer() )
    fen.mainloop()
