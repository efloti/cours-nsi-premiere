from acteur import Acteur
from missile import Missile
from random import choice, random

class Envahisseur(Acteur):
    
    def __init__(self, scene, couleur="red"):
        super().__init__(scene, largeur=50, hauteur=30, couleur=couleur)
        # choisir une vitesse au hasard
        self.v = choice([-100, 100])
        
        # régler la position de façon à apparaîte en haut
        # à gauche ou à droite selon la vitesse ...
        l, _ = self.dim
        if self.v > 0:
            self.set_position(-l+10, 30)
        else:
            self.set_position(self.L-10, 30)
        
        # tout est prêt! lançons le.
        self._lancer()

    # un underscore devant une fonction est une *convention* pour 
    # indiquer que celle-ci ne doit pas être utilisée en dehors de la classe
    def _lancer(self, duree_milli=50):
        if self.est_hors_scene():
            self.supprimer()
            return
        
        self.deplacer_duree(duree_milli / 1000)
        
        # random() renvoie un nombre dans [0;1]
        # utilisons le pour tirer aléatoirement
        if random() < 0.025:
            self.tirer()
        
        self.scene.after(
            duree_milli,
            lambda: self._lancer(duree_milli),
        )
    
    def tirer(self):
        x, y = self.pos
        l, h = self.dim
        m = Missile(self.scene)
        m.set_position(x + l//2, y + h)
        m.set_vitesse(300)
        m.lancer()
    
    def __del__(self):
        print("supprimer")

if __name__ == "__main__":
    from scene import *
    from hero import Hero
    env = Envahisseur(scene)
    hero = Hero(scene)
    fen.mainloop()
