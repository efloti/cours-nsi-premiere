from acteur import Acteur
from missile import Missile

class Hero(Acteur):
    
    def __init__(self, scene, couleur="white"):
        super().__init__(scene, largeur=50, hauteur=30, couleur=couleur)
        
        self.reagir('<Left>', self.gauche)
        self.reagir('<Right>', self.droite)
        self.reagir('<space>', self.tirer)
        
        self.pas = 10
        self.set_position(self.L//2, self.H-50)
    
    def gauche(self):
        if self.est_dans_scene(-self.pas, 0):
            self.deplacer(-self.pas, 0)
    
    def droite(self):
        if self.est_dans_scene(self.pas, 0):
            self.deplacer(self.pas, 0)
    
    def tirer(self):
        x, y = self.pos
        l, _ = self.dim
        m = Missile(self.scene)
        _, hm = m.dim
        m.set_position(x + l//2, y + hm)
        m.set_vitesse(-300)
        m.lancer()
    

if __name__ == "__main__":
    from scene import *
    hero = Hero(scene)
    fen.mainloop()
