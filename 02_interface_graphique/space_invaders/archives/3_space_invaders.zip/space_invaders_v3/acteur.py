# module space_invaders/acteur.py
class Acteur():
    
    def __init__(self, scene, largeur, hauteur, couleur="white"):
        self.scene = scene
        self.fen = scene.winfo_toplevel()
        self.L = int(scene["width"])
        self.H = int(scene["height"])
        
        self.dim = largeur, hauteur
        self.pos = 0, 0
        self.v = 0 # vitesse en pixel par seconde
        
        self.id = scene.create_rectangle(0, 0, largeur, hauteur, fill=couleur)
    
    def supprimer(self):
        "Efface l'acteur de la scene"
        
        self.scene.delete(self.id)
    
    def set_position(self, x, y):
        "Met l'acteur dans la position indiquée"
        
        x0, y0 = self.pos
        self.pos = x, y
        self.scene.move(self.id, x-x0, y-y0)
    
    def deplacer(self, dx, dy):
        "Déplace l'acteur de dx pixels horizontalement et de dy pixels verticalement"
        
        x0, y0 = self.pos
        self.set_position(x0+dx, y0+dy)
 
    def deplacer_duree(self, duree, direction="h"):
        """Déplace l'acteur en utilisant sa vitesse (horizontalement par défaut)
        «duree» est supposé être en seconde
        """
        
        if direction == "h":
            dx = self.v * duree
            self.deplacer(dx, 0)
        else:
            dy = self.v * duree
            self.deplacer(0, dy)
    
    def set_vitesse(self, v):
        self.v = v

    def reagir(self, evt_type, gestionnaire):
        return self.fen.bind(evt_type, lambda _: gestionnaire())
    
    def est_hors_scene(self):
        """Test si l'acteur est entièrement hors de la scène"""
        
        x, y = self.pos
        l, h = self.dim
        return x + l < 0 or x >= self.L or y + h < 0 or y >= self.H
    
    def est_dans_scene(self, dx=0, dy=0):
        """Test si l'acteur est entièrement dans la scène,
        après un déplacement (virtulel) dx, dy s'il est précisé"""
        
        x, y = self.pos
        x, y = x + dx, y + dy
        l, h = self.dim
        return x >= 0 and x + l <= self.L and y >= 0 and y + h <= self.H
    


if __name__ == "__main__":
    # zone pour tester son code
    from scene import *
    acteur = Acteur(scene, 100, 100)
    acteur.set_position(acteur.L - 50, 100)
    assert not acteur.est_dans_scene()
    assert not acteur.est_hors_scene()
    scene.pack()
    acteur.reagir("<Left>", lambda : acteur.deplacer(-5, 0) )
    acteur.reagir("<Right>", lambda : acteur.deplacer(5, 0) )
    fen.mainloop()
